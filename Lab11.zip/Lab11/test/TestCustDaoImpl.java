

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.emp.bean.CustomerBean;
import com.emp.dao.CustomerDaoImpl;
import com.emp.exception.MobileException;


public class TestCustDaoImpl 
{
	static CustomerDaoImpl employeeDao;
	static CustomerBean empBean;
	
	@BeforeClass
	public static void beforeClass()
	{
		employeeDao =new CustomerDaoImpl();
		empBean = new CustomerBean();
	}
	
	@Test
	public void testAddEmployeeDetails() throws MobileException
	{
		assertNotNull(employeeDao.addCustomer(empBean));
	}
	
	
	@Test
	public void testAddEmployee() throws MobileException
	{
		empBean.setCname("Riya");
		empBean.setMailid("riya@gmail.in");
		empBean.setPhoneno("9087634562");
		empBean.setMobileid(1001);
		int id = employeeDao.addCustomer(empBean);
		assertTrue(id>0);
	}
	
	@Ignore
	@Test
	public void testAddMobileDetails1() throws MobileException {
		// increment the number next time you test for positive test case
		assertEquals(1001, employeeDao.addCustomer(empBean));
	}
	
	@Test
	public void testViewMobileById() throws MobileException
	{
		assertNotNull(employeeDao.viewMobById(1001));
	}
	
	@Test
	public void testViewMobById1() throws MobileException {
		assertEquals("Sony xperia C", employeeDao.viewMobById(1003).getName());
	}
	
	@Test
	public void testViewAll() throws MobileException {
		assertNotNull(employeeDao.viewAllMob());
	}
}
