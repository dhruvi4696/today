package com.emp.dao;

import java.util.List;

import com.emp.bean.CustomerBean;
import com.emp.bean.MobileBean;
import com.emp.exception.MobileException;

public interface CustomerDao 
{
	public int addCustomer(CustomerBean bean) throws MobileException; 
	public int deleteMob(int deleteId) throws MobileException;
	public List<MobileBean> viewAllMob() throws MobileException;
	public MobileBean viewMobById(int empid) throws MobileException;
	public List<MobileBean> searchByRange(int min,int max) throws MobileException;
}
