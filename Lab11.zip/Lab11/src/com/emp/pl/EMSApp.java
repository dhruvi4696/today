package com.emp.pl;

import java.util.List;
import java.util.Scanner;

import com.emp.bean.CustomerBean;
import com.emp.bean.MobileBean;
import com.emp.exception.MobileException;
import com.emp.service.CustomerService;
import com.emp.service.CustomerServiceImpl;

public class EMSApp 
{
	public static void main(String[] args) 
	{
		int ch;
		Scanner sc = new Scanner (System.in);
		do
		{
			System.out.println("1.add customer purchase details");
			System.out.println("2.delete mobile detail by id");
			System.out.println("3.view  mobile details by id");
			System.out.println("4.view all mobile detail by");
			System.out.println("5.search mobiles based on price range");	
			int choice = sc.nextInt();
		
		switch(choice)
		{
		case 1:
			System.out.println("enter customer name : ");
			String name = sc.next();
			System.out.println("enter customer mailid : ");
			String mail = sc.next();
			System.out.println("enter customer phone no : ");
			String phone = sc.next();
			System.out.println("enter customer mobileid : ");
			int mobid = sc.nextInt();
			
			CustomerBean bean = new CustomerBean();
			bean.setCname(name);
			bean.setMailid(mail);
			bean.setPhoneno(phone);
			bean.setMobileid(mobid);
			
			CustomerService service = new CustomerServiceImpl();
			
			try
			{
				if(service.validateDetails(bean))
				{
				int n = service.addCustomer(bean);
				System.out.println("customer details added! id = "+n);
			}
			else
			{
				throw new MobileException("invalid data!");
			}
			}
			catch (MobileException e) 
			{	
				System.out.println(e);
			}
			break;
		
		case 2:
			System.out.println("enter id you want to delete : ");
			int deleteId = sc.nextInt();
			CustomerService service1 = new CustomerServiceImpl();
			
			try {
				int id =service1.deleteMob(deleteId);
				System.out.println("employee deleted! id = "+id);
			}
			catch (MobileException e) 
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case 3:
			System.out.println("enter id you want to view : ");
			int viewId = sc.nextInt();
			CustomerService service2 = new CustomerServiceImpl();
			
			try {
				MobileBean bean1  =service2.viewMobById(viewId);
				System.out.println("The details of id : "+viewId+"\n"+"***************************");
				System.out.println(bean1.toString());//getEmployeeId()+" "+bean1.getEmployeeName()+" "+bean1.getEmployeesalary());
			}
			catch (MobileException e) 
			{
				System.out.println(e);
			}
			break;
			
		case 4:
			CustomerService service3 = new CustomerServiceImpl();
			try {
				List<MobileBean> list=service3.viewAllMob();
				System.out.println("The details of all employees:\n *************************** ");
				 for(MobileBean bean1 : list)
				 {
					 System.out.println(bean1.toString());//getEmployeeId()+" "+bean1.getEmployeeName()+" "+bean1.getEmployeesalary());
				 }				
			}
			catch (MobileException e) 
			{
				e.printStackTrace();
			}
			break;
			
		case 5:
			CustomerService service4 = new CustomerServiceImpl();
			System.out.println("Enter price range to serach mobiles: ");
			int min =sc.nextInt();
			int max=sc.nextInt();

			try {
				List<MobileBean> list=service4.searchByRange(min,max);
				System.out.println("The details of all mobiless:\n *************************** ");
				 for(MobileBean bean1 : list)
				 {
					 System.out.println(bean1.toString());//getEmployeeId()+" "+bean1.getEmployeeName()+" "+bean1.getEmployeesalary());
				 }
			} 
			catch (MobileException e)
			{
				System.out.println(e);
			}	
			break;
			
		default:
			System.out.println("enter valid choice!");
		}
		System.out.println("\n->Enter 1 for continue.\n->Enter 2 for exit");
		 ch = sc.nextInt();
		}while(ch==1);
		sc.close();
	}
}

